const BROWSER = false;
export {
  BROWSER as B
};
