

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/admin/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/5.yxjVLlUZ.js","_app/immutable/chunks/BVSBLeZ4.js","_app/immutable/chunks/CyUuy-wj.js","_app/immutable/chunks/DN5HFw78.js","_app/immutable/chunks/DxC-crzK.js","_app/immutable/chunks/VH3MxTbr.js","_app/immutable/chunks/u-DmHNmw.js","_app/immutable/chunks/PPVm8Dsz.js"];
export const stylesheets = [];
export const fonts = [];
