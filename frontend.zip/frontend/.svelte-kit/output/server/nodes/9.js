

export const index = 9;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/admin/database/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/9.C6ROKO-5.js","_app/immutable/chunks/BVSBLeZ4.js","_app/immutable/chunks/CyUuy-wj.js","_app/immutable/chunks/VH3MxTbr.js","_app/immutable/chunks/u-DmHNmw.js","_app/immutable/chunks/PPVm8Dsz.js","_app/immutable/chunks/DxC-crzK.js"];
export const stylesheets = [];
export const fonts = [];
