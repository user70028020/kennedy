

export const index = 4;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/4.B0U3uS8d.js","_app/immutable/chunks/BVSBLeZ4.js","_app/immutable/chunks/CyUuy-wj.js","_app/immutable/chunks/B9KgWSyi.js","_app/immutable/chunks/DN5HFw78.js","_app/immutable/chunks/DxC-crzK.js","_app/immutable/chunks/VH3MxTbr.js","_app/immutable/chunks/u-DmHNmw.js","_app/immutable/chunks/PPVm8Dsz.js"];
export const stylesheets = [];
export const fonts = [];
