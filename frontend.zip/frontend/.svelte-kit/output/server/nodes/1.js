

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.DUegdK4c.js","_app/immutable/chunks/BVSBLeZ4.js","_app/immutable/chunks/CyUuy-wj.js","_app/immutable/chunks/DG4n1pGD.js","_app/immutable/chunks/Ds7I-RoO.js","_app/immutable/chunks/VH3MxTbr.js","_app/immutable/chunks/u-DmHNmw.js","_app/immutable/chunks/PPVm8Dsz.js","_app/immutable/chunks/CgjK9u-w.js"];
export const stylesheets = [];
export const fonts = [];
