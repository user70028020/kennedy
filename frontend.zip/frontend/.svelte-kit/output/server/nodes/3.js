

export const index = 3;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/relatorios/_layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/3.CrflJ-GE.js","_app/immutable/chunks/BVSBLeZ4.js","_app/immutable/chunks/CyUuy-wj.js","_app/immutable/chunks/B9KgWSyi.js","_app/immutable/chunks/yBHeIKn2.js","_app/immutable/chunks/DN5HFw78.js","_app/immutable/chunks/DxC-crzK.js","_app/immutable/chunks/VH3MxTbr.js","_app/immutable/chunks/u-DmHNmw.js","_app/immutable/chunks/PPVm8Dsz.js","_app/immutable/chunks/CeoiFMeb.js","_app/immutable/chunks/Ds7I-RoO.js","_app/immutable/chunks/it7mHTr0.js","_app/immutable/chunks/DG4n1pGD.js","_app/immutable/chunks/DwPpHslU.js","_app/immutable/chunks/DNhq2NOS.js","_app/immutable/chunks/SJb4weSm.js","_app/immutable/chunks/D5Lyc911.js","_app/immutable/chunks/BUYgxnM0.js","_app/immutable/chunks/c2Jz6SHd.js","_app/immutable/chunks/Ds5fY43x.js","_app/immutable/chunks/CgjK9u-w.js","_app/immutable/chunks/DdEIAL_0.js","_app/immutable/chunks/CMByNPU3.js","_app/immutable/chunks/k3Q1lqoc.js","_app/immutable/chunks/DTBq4SVp.js","_app/immutable/chunks/axbQqOQH.js","_app/immutable/chunks/DvfD3L-c.js","_app/immutable/chunks/BZWVT1Ld.js","_app/immutable/chunks/CLPOYvp8.js"];
export const stylesheets = ["_app/immutable/assets/ModernSelect.CaXWGSM2.css","_app/immutable/assets/AdminSidebar.9aH-9DY2.css","_app/immutable/assets/StatusSelector.D5X3iU8G.css"];
export const fonts = [];
